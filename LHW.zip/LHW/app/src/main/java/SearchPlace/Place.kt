package SearchPlace

data class Place(val name : String,
            val add : String,
            val longitude : Double,
            val latitude : Double)