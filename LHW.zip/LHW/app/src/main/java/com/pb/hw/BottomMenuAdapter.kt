package com.pb.hw

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter

class BottomMenuAdapter(fm: FragmentManager, n : Int) : FragmentStatePagerAdapter(fm) {
    private val mPageCount = n


    override fun getItem(p0: Int): Fragment {
        return when(p0){
            1 -> Bottom_menu2()
            2 -> Bottom_menu3()
            3 -> Bottom_menu4()
            else -> Bottom_menu1()
        }
    }

    override fun getCount(): Int {
        return mPageCount
    }
}