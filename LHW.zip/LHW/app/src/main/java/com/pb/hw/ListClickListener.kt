package com.pb.hw

interface ListClickListener {
    fun onListClick(what : Int , pos : Int)
}