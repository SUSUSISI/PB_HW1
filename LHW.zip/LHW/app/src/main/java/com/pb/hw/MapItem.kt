package com.pb.hw

data class MapItem(val name:String, val image:Int)
