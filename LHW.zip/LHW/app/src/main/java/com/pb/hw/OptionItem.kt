package com.pb.hw

data class OptionItem(val option_icon:Int, val name:String, val check_icon:Int, var checked:Int)
